package com.calculadoracalorias.demo.exceptions;

public class IngredientNotFound extends Exception{

    public IngredientNotFound(String msg)
    {
        super(msg);
    }
}
